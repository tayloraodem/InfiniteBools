//  infiniteBools.cpp
//
//  Author: Steven R. Vegdahl, October 2018
//  Author: Taylor Odem
//

#include <cstddef>
#include "infiniteBools.h"
#include <string>

using namespace std;

// constructor for linked list node
LinkedListNode::LinkedListNode(int value, LinkedListNode* next) : value(value), next(next){
}

//destructor for linked list node
LinkedListNode::~LinkedListNode() {
	if (next != NULL) {
		delete(next);
	}
}

// no-argument consstructor
InfiniteBools::InfiniteBools():
negHeader(NULL), nonNegHeader(NULL), defaultNegValue(false), defaultNonNegValue(false) {
    
    nonNegHeader = new LinkedListNode(false, NULL);
	negHeader = new LinkedListNode(false, NULL);
}

// 3-argument consstructor
InfiniteBools::InfiniteBools(bool n, bool z, bool p):
negHeader(NULL), nonNegHeader(NULL), defaultNegValue(n), defaultNonNegValue(p) {
    
    nonNegHeader = new LinkedListNode(z, NULL);
	negHeader = new LinkedListNode(n, NULL);
}

//copy constructor
InfiniteBools::InfiniteBools(const InfiniteBools &obj){

	this->negHeader = new LinkedListNode(obj.negHeader->value, NULL);
	this->nonNegHeader = new LinkedListNode(obj.nonNegHeader->value, NULL);
	
	LinkedListNode * nextAd;
	nextAd = this->negHeader;
	LinkedListNode * nextOrigAd;
	nextOrigAd = obj.negHeader->next;

	while (nextOrigAd != NULL) {
		
		nextAd->next = new LinkedListNode(nextOrigAd->value,NULL);
		nextAd = nextAd->next;
		nextOrigAd = nextOrigAd->next;
	}

	nextAd = this->nonNegHeader;
	nextOrigAd = obj.nonNegHeader->next;

	while (nextOrigAd != NULL) {
		
		nextAd->next = new LinkedListNode(nextOrigAd->value, NULL);
		nextAd = nextAd->next;
		nextOrigAd = nextOrigAd->next;
	}
}

//destructor
InfiniteBools::~InfiniteBools() {
	
	if (negHeader->next != NULL) {
		delete(negHeader->next);
	}
	if (nonNegHeader->next != NULL) {
		delete(nonNegHeader->next);
	}
	
}

bool& InfiniteBools::operator[](int idx) {
    
	if (idx == 0) {
		return nonNegHeader->value;
	}
	else if (idx < 0) {

		LinkedListNode * nextAd;
		int i = -1;

		if (negHeader->next == NULL) {

			negHeader->next = new LinkedListNode(defaultNegValue, NULL);
			nextAd = negHeader->next;
			i--;
		}
		else {
			nextAd = negHeader;
			while (nextAd != NULL) {
				if (i == idx) {
					return nextAd->value;
				}
				if (nextAd->next == NULL) {
					break;
				}
				nextAd = nextAd->next;
				i--;
			}
		}
		while (i != idx) {
			nextAd->next = new LinkedListNode(defaultNegValue, NULL);
			nextAd = nextAd->next;
			i--;
		}
		return nextAd->value;
	}
	else {
		LinkedListNode * nextAd;
		int i = 0;

		if (nonNegHeader->next == NULL) {
			
			nonNegHeader->next = new LinkedListNode (defaultNonNegValue, NULL);
			nextAd = nonNegHeader->next;
			i++;
		}
		else {
			
			nextAd = nonNegHeader;
			while (nextAd != NULL) {
				if (i == idx) {
					return nextAd->value;
				}
				if (nextAd->next == NULL) {
					break;
				}
				nextAd = nextAd->next;
				i++;
			}
		}
		while (i != idx) {
			nextAd->next = new LinkedListNode(defaultNonNegValue, NULL);
			nextAd = nextAd->next;
			i++;
		}
		return nextAd->value;
	}
	
	
}

// output operator
std::ostream& operator <<(std::ostream& os, InfiniteBools const& obj) {

	bool negCap = false;
	bool nonNegCap = false;

	os << "[...";

	LinkedListNode * nextNegAd;
	nextNegAd = obj.negHeader;
	std::string neg = "";
	int defNegCount = 0;
	while (nextNegAd != NULL) {
		if (nextNegAd->value != obj.defaultNegValue) {

			negCap = true;

			for (int i = 0;i < defNegCount;i++) {
				if (obj.defaultNegValue) {
					neg = "T" + neg;
				}
				else {
					neg = "F" + neg;
				}
			}

			if (obj.defaultNegValue) {
				neg = "F" + neg;
			}
			else {
				neg = "T" + neg;
			}
			defNegCount = 0;
		}
		else {

			defNegCount++;
		}
		nextNegAd = nextNegAd->next;
	}

	if (negCap) {
		if (obj.defaultNegValue) {
			os << "T";
		}
		else {
			os << "F";
		}
	}
	
	os << neg;

	os << "<";
	if (obj.nonNegHeader->value) { 
		os << "T"; 
	}
	else {
		os << "F";
	}
	os << ">";

	LinkedListNode * nextAd;
	nextAd = obj.nonNegHeader->next;
	int defCount = 0;
	while (nextAd != NULL) {
		if (nextAd->value != obj.defaultNonNegValue) {
			nonNegCap = true;
			for (int i = 0;i < defCount;i++) {
				if (obj.defaultNonNegValue) {
					os << "T";
				}
				else {
					os << "F";
				}
			}

			if (obj.defaultNonNegValue) {
				os << "F";
			}
			else {
				os << "T";
			}
			defCount = 0;
		}
		else {

			defCount++;
		}
		nextAd = nextAd->next;
	}

	if (nonNegCap) {
		if (obj.defaultNegValue) {
			os << "T";
		}
		else {
			os << "F";
		}
	}
	os << "...]";
    return os;
}

//assignment operator
InfiniteBools InfiniteBools::operator =(InfiniteBools const& src) {
	
	InfiniteBools copy(src);
	
	return copy;
}
